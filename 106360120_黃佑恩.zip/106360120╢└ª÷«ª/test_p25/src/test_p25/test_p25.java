package test_p25;

public class test_p25 {

	public static void main(String[] args) {
		int num;
		num = 3;
		System.out.println("�ܼƪ�num�ȬO"+num);

	}

}
