package test_p10;

public class test_p10 {

	public static void main(String[] args) {
		System.out.println("�w��ϥ�java!");
		System.out.println("�}�l�ϥ�java�a!");

	}

}
